package com.atharva.UserInfo.Controller;

import com.atharva.UserInfo.Model.User;
import com.atharva.UserInfo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("/api/public/users")
    public List<User> getUsers() {
        return userService.getAllUsers();
    }

    @PostMapping("api/public/createUser")
    public String CreateUser(@RequestBody User user) {
        userService.createUser(user);
        return  "User created";
    }


    @DeleteMapping("/api/public/users/{userId}")
    public String deleteUser(@PathVariable Long userId) {
        String status = userService.deleteUser(userId);
        return status;
    }

    @PutMapping("/api/public/users/{userId}")
    public String updateUser(@PathVariable Long userId, @RequestBody User user) {
        String status= userService.updateUser(user,userId);
        return status;
    }

}
