package com.atharva.UserInfo.service;

import com.atharva.UserInfo.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    private List<User> usersList = new ArrayList<>();
    private Long nextId=1L;

    @Override
    public List<User> getAllUsers() {
        return usersList;
    }

    @Override
    public void createUser(User user) {
        user.setUserId(nextId++);
        usersList.add(user);
    }

    @Override
    public String deleteUser(Long userId) {
        Optional<User> user = getAllUsers().stream()
                .filter(c ->c.getUserId().equals(userId))
                .findFirst();
        getAllUsers().remove(user.orElse(null));
        return "User With userID"+ userId +" Deleted";
    }

    @Override
    public String updateUser(User user, Long userId) {
        List<User> uList = getAllUsers();
        for(int i = 0; i < uList.size(); i++) {
            User existingUser = uList.get(i);
            if (existingUser.getUserId().equals(userId)) {
                existingUser.setFirstName(user.getFirstName());
                existingUser.setLastName(user.getLastName());
                existingUser.setEmail(user.getEmail());
                return "User with userID " + user.getUserId() + " updated successfully.";
            }
        }
        return "User with userID " + user.getUserId() + " not found.";

    }
}
